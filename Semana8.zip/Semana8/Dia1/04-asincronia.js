/**
 * que estamos jugando monopolio y nos da hambre, pedimos un rappi con algunás pizzas y después comemos cuando llegue el rappi
 */

console.log("1. Estamos jugando monopolio y nos dio hambre");

//como el rappi va a demorar
setTimeout(function () {
    console.log("2. Esperar al Rappi hasta que llegue");
}, 2000);

console.log("3. llega el Rappi y comemos");

//JAVASCRIPT SOLAMENTE PUEDE EJECUTAR 01 TAREA A LA VEZ
